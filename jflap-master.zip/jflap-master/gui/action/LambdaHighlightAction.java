/* -- JFLAP 4.0 --
 *
 * Copyright information:
 *
 * Susan H. Rodger, Thomas Finley
 * Computer Science Department
 * Duke University
 * April 24, 2003
 * Supported by National Science Foundation DUE-9752583.
 *
 * Copyright (c) 2003
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that the above copyright notice and this paragraph are
 * duplicated in all such forms and that any documentation,
 * advertising materials, and other materials related to such
 * distribution and use acknowledge that the software was developed
 * by the author.  The name of the author may not be used to
 * endorse or promote products derived from this software without
 * specific prior written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */
 
package gui.action;

import automata.*;
import gui.editor.ArrowDisplayOnlyTool;
import gui.environment.Environment;
import gui.environment.tag.CriticalTag;
import gui.viewer.*;
import java.awt.BorderLayout;
import java.awt.event.*;
import java.util.*;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * This is an action that will highlight all states that have
 * lambda-transitions.
 * 
 * @author Thomas Finley
 */

public class LambdaHighlightAction extends AutomatonAction {
    public LambdaHighlightAction(Automaton automaton,
				 Environment environment) {
	super("Highlight \u03BB-Transitions", null);
	this.automaton = automaton;
	this.environment = environment;
    }

    public void actionPerformed(ActionEvent event) {
	Transition[] t = automaton.getTransitions();
	Set lambdas = new HashSet();
	LambdaTransitionChecker checker =
	    LambdaCheckerFactory.getLambdaChecker(automaton);
	for (int i=0; i<t.length; i++)
	    if (checker.isLambdaTransition(t[i]))
		lambdas.add(t[i]);
	
	// Create the selection drawer thingie.
	SelectionDrawer as = new SelectionDrawer(automaton);
	Iterator it = lambdas.iterator();
	while (it.hasNext()) {
	    Transition lt = (Transition) it.next();
	    as.addSelected(lt);
	}

	// Put that in the environment.
	LambdaPane pane = new LambdaPane(new AutomatonPane(as));
	environment.add(pane, "\u03BB-Transitions", new CriticalTag() {});
	environment.setActive(pane);
    }

    /**
     * A class that exists to make integration with the help system
     * feasible.
     */
    private class LambdaPane extends JPanel {
	public LambdaPane(AutomatonPane ap) {
	    super(new BorderLayout());
	    add(ap, BorderLayout.CENTER);
	    add(new JLabel("\u03BB-transitions are highlighted."),
		BorderLayout.NORTH);
	    ArrowDisplayOnlyTool tool =
		new ArrowDisplayOnlyTool(ap, ap.getDrawer());
	    ap.addMouseListener(tool);
	}
    }

    /** The automaton to find the lambda-transitions of. */
    private Automaton automaton;
    /** The environment to add the pane with the highlighted lambdas to. */
    private Environment environment;
}
